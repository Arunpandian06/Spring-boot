package com.payanam.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.payanam.model.User;
import com.payanam.repository.UserRepository;
import com.payanam.security.WebSecurityConfig;
import com.payanam.service.UserService;

@Service
public class UserServiceImpl implements UserService{
	
	@Autowired
	private WebSecurityConfig passwordEncoder;
	
	@Autowired
	private UserRepository userRepository;

	@Override
	public List<User> findAll() {
		// TODO Auto-generated method stub
		return (List<User>) userRepository.findAll();
	}

	@Override
	public void saveUser(User user) {
		// TODO Auto-generated method stub
		System.out.println("user : "+user);
		user.setPassword(passwordEncoder.passwordEncoder().encode(user.getPassword()));
		userRepository.save(user);
	}

	@Override
	public User findByUserName(String userName) {
		// TODO Auto-generated method stub
		User user = userRepository.findByUserName(userName);
		return user;
	}
}
