package com.payanam.service;

import java.util.List;

import com.payanam.model.User;

public interface UserService {

	List<User> findAll();
	
	void saveUser(User user);
	
	User findByUserName(String userName);
}
