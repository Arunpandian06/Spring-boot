package com.payanam.jwt;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User.UserBuilder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.payanam.model.User;
import com.payanam.serviceImpl.UserServiceImpl;

@Service
public class JwtUserDetailsService implements UserDetailsService {

	@Autowired
	UserServiceImpl userServiceImpl;
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		// TODO Auto-generated method stub
		User user = userServiceImpl.findByUserName(username);
		 UserBuilder builder = null;
		    if (user != null) {
		      builder = org.springframework.security.core.userdetails.User.withUsername(username);
		      builder.password(user.getPassword());
		      builder.roles("ADMIN");
		    } else {
		      throw new UsernameNotFoundException("User not found.");
		    }
		    return builder.build();
		
//		return new JwtUserDetails(user);
	}
	
	
}