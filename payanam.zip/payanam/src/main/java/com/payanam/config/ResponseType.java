package com.payanam.config;

public enum ResponseType {

}
