package com.payanam.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.payanam.model.User;

public interface UserRepository extends CrudRepository<User, String>{

//	c- creat
//	r - read
//	u -update
//	d -delete
	
	
	@Query("FROM User u WHERE u.mobile = :userName")
    User findByUserName(@Param("userName") String userName);
}

