package com.payanam.model;

import java.sql.Date;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;


@Entity
@Table(name="user")
public class User {

	@Id
	@GeneratedValue(generator = "uuid2")
	@GenericGenerator(name = "uuid2", strategy = "uuid2")
	@Column(columnDefinition = "BINARY(16)")
	private UUID id;

	@Column(name = "countrycode", nullable = false, columnDefinition = "VARCHAR(5) default '+91'") 
	private String countryCode;
	
	private String mobile;
	
	private String password;
	
	@Column(name = "isactive", nullable = false, columnDefinition = "boolean default false")
	private Boolean isActive;
	
	@Column(name = "createdby")
	private String createdBy;
	
	@Column(name = "createddate")
	private Date createdDate;
	
	@Column(name = "updatedby")
	private String updatedBy;
	
	@Column(name = "updateddate")
	private Date updateddDate;
	
	public void setId(UUID id) {
		this.id = id;
	}
	
	public UUID getId() {
		return this.id;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}
	
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	
	public String getCreatedBy() {
		return createdBy;
	}
	
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	
	public Date getCreatedDate() {
		return createdDate;
	}
	
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	
	public String getUpdatedBy() {
		return updatedBy;
	}
	
	public void setUpdatedDate(Date updatedDate) {
		this.updateddDate = updatedDate;
	}
	
	public Date getUpdatedDate() {
		return updateddDate;
	}

	

	/*
	 * Pre save method
	 */
	@PrePersist
	void prePersist() {
	    if (this.countryCode == null) {
	    	this.countryCode= "+91";
	    }
	}
	
	
}
