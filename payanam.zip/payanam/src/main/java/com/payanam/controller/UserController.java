package com.payanam.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.payanam.model.User;
import com.payanam.service.UserService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.Authorization;

@RestController
@RequestMapping("/user")
public class UserController {

	@Autowired
	private UserService userService;
	
//	@ApiOperation(value = "", authorizations = { @Authorization(value="Authorization") })
	@RequestMapping(value="/getAllUser", method= RequestMethod.GET, produces=MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody Iterable<User> getAllUser(){
		return userService.findAll();
	}
	
	
	@RequestMapping(value="/register", method= RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> userRegister(@RequestBody User user){
		userService.saveUser(user);
		return new ResponseEntity<>(HttpStatus.CREATED);
	}
}
